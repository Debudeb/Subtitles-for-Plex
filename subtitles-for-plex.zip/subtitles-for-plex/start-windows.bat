@echo off
rem Starts Subtitles for Plex and opens it in your browser.
rem Keep this window open while you use it. Close it to stop.
setlocal
cd /d "%~dp0"
title Subtitles for Plex

rem Optional settings. Remove "rem " at the start of a line to use it.
rem set SUBTITLES_FOR_PLEX_PASSWORD=choose-a-long-password
rem set SUBTITLES_FOR_PLEX_PORT=8765

set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (
    python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo.
    echo Python 3 is not installed.
    echo.
    echo 1. Download it from https://www.python.org/downloads/
    echo 2. In the installer, tick "Add python.exe to PATH".
    echo 3. Then double-click start-windows.bat again.
    echo.
    pause
    exit /b 1
)

rem Opens the browser, unless started with --no-browser (e.g. from the Startup folder).
set "OPEN=--open"
if /i "%~1"=="--no-browser" set "OPEN="

%PY% subtitles_for_plex.py %OPEN%
echo.
pause
