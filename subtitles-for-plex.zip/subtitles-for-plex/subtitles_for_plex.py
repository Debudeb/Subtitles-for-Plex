#!/usr/bin/env python3
"""Subtitles for Plex - fetch subtitles in your language from OpenSubtitles for a Plex library.

Uses only the Python standard library. Run it with:

    python3 subtitles_for_plex.py

then open http://<this-machine>:8765 in any browser on your network.
"""
import base64
import hmac
import io
import ipaddress
import json
import os
import re
import secrets
import socket
import struct
import threading
import time
import zlib
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP = "Subtitles for Plex"
VERSION = "1.0"
USER_AGENT = f"SubtitlesForPlex v{VERSION}"
API_ROOT = "https://api.opensubtitles.com/api/v1"
HOST = os.environ.get("SUBTITLES_FOR_PLEX_HOST", "0.0.0.0")
PORT = int(os.environ.get("SUBTITLES_FOR_PLEX_PORT", "8765"))
CONFIG_PATH = Path(os.environ.get(
    "SUBTITLES_FOR_PLEX_CONFIG", Path.home() / ".config" / "subtitles-for-plex" / "config.json"))
HERE = Path(__file__).resolve().parent

# Access control. The web page has no accounts, so by default only devices on the local
# network may use it, and only under this machine's own names (blocks DNS rebinding).
PASSWORD = os.environ.get("SUBTITLES_FOR_PLEX_PASSWORD", "")
ALLOW_PUBLIC = os.environ.get("SUBTITLES_FOR_PLEX_ALLOW_PUBLIC", "") == "1"
ALLOWED_HOSTS = {h.strip().lower() for h in
                 os.environ.get("SUBTITLES_FOR_PLEX_ALLOWED_HOSTS", "").split(",") if h.strip()}
ALLOWED_HOSTS |= {"localhost", socket.gethostname().lower(), socket.gethostname().lower() + ".local"}

VIDEO_EXT = {".mkv", ".mp4", ".avi", ".m4v", ".mov", ".wmv", ".ts",
             ".m2ts", ".webm", ".mpg", ".mpeg", ".divx", ".flv"}
SKIP_DIRS = {"@eadir", "#recycle", "$recycle.bin", "#snapshot", ".@__thumb", "lost+found"}
SUB_EXT = {".srt", ".ass", ".ssa", ".vtt", ".smi"}
MAX_SUB_BYTES = 5_000_000
MAX_BODY_BYTES = 64_000_000
MAX_ZIP_FILES = 300
MAX_STAGED_BYTES = 200_000_000  # imported subtitles waiting to be saved, all uploads together

# OpenSubtitles language code: (English name, tag used in the subtitle file name,
# other ways the language is written in file names).
LANGUAGES = {
    "af": ("Afrikaans", "af", "afr"),
    "sq": ("Albanian", "sq", "sqi alb"),
    "ar": ("Arabic", "ar", "ara"),
    "hy": ("Armenian", "hy", "hye arm"),
    "eu": ("Basque", "eu", "eus baq"),
    "be": ("Belarusian", "be", "bel"),
    "bn": ("Bengali", "bn", "ben"),
    "bs": ("Bosnian", "bs", "bos"),
    "br": ("Breton", "br", "bre"),
    "bg": ("Bulgarian", "bg", "bul"),
    "my": ("Burmese", "my", "mya bur"),
    "ca": ("Catalan", "ca", "cat"),
    "zh-CN": ("Chinese (simplified)", "zh", "zho chi chs"),
    "zh-TW": ("Chinese (traditional)", "zh", "zho chi cht"),
    "hr": ("Croatian", "hr", "hrv"),
    "cs": ("Czech", "cs", "ces cze"),
    "da": ("Danish", "da", "dan dansk"),
    "nl": ("Dutch", "nl", "nld dut nederlands"),
    "en": ("English", "en", "eng"),
    "eo": ("Esperanto", "eo", "epo"),
    "et": ("Estonian", "et", "est"),
    "fi": ("Finnish", "fi", "fin suomi"),
    "fr": ("French", "fr", "fra fre francais"),
    "gl": ("Galician", "gl", "glg"),
    "ka": ("Georgian", "ka", "kat geo"),
    "de": ("German", "de", "deu ger deutsch"),
    "el": ("Greek", "el", "ell gre"),
    "he": ("Hebrew", "he", "heb"),
    "hi": ("Hindi", "hin", "hindi"),  # ".hi" in file names usually means hearing impaired
    "hu": ("Hungarian", "hu", "hun"),
    "is": ("Icelandic", "is", "isl ice"),
    "id": ("Indonesian", "id", "ind"),
    "it": ("Italian", "it", "ita italiano"),
    "ja": ("Japanese", "ja", "jpn"),
    "kn": ("Kannada", "kn", "kan"),
    "kk": ("Kazakh", "kk", "kaz"),
    "km": ("Khmer", "km", "khm"),
    "ko": ("Korean", "ko", "kor"),
    "ku": ("Kurdish", "ku", "kur"),
    "lv": ("Latvian", "lv", "lav"),
    "lt": ("Lithuanian", "lt", "lit"),
    "lb": ("Luxembourgish", "lb", "ltz"),
    "mk": ("Macedonian", "mk", "mkd mac"),
    "ms": ("Malay", "ms", "msa may"),
    "ml": ("Malayalam", "ml", "mal"),
    "mn": ("Mongolian", "mn", "mon"),
    "no": ("Norwegian", "no", "nor nob nb norsk"),
    "oc": ("Occitan", "oc", "oci"),
    "fa": ("Persian", "fa", "fas per farsi"),
    "pl": ("Polish", "pl", "pol polski"),
    "pt-PT": ("Portuguese", "pt", "por portugues"),
    "pt-BR": ("Portuguese (Brazil)", "pt", "por pob pb portugues"),
    "ro": ("Romanian", "ro", "ron rum"),
    "ru": ("Russian", "ru", "rus"),
    "sr": ("Serbian", "sr", "srp"),
    "si": ("Sinhala", "si", "sin"),
    "sk": ("Slovak", "sk", "slk slo"),
    "sl": ("Slovenian", "sl", "slv"),
    "so": ("Somali", "so", "som"),
    "es": ("Spanish", "es", "spa espanol"),
    "sw": ("Swahili", "sw", "swa"),
    "sv": ("Swedish", "sv", "swe svenska"),
    "tl": ("Tagalog", "tl", "tgl"),
    "ta": ("Tamil", "ta", "tam"),
    "te": ("Telugu", "te", "tel"),
    "th": ("Thai", "th", "tha"),
    "tr": ("Turkish", "tr", "tur"),
    "uk": ("Ukrainian", "uk", "ukr"),
    "ur": ("Urdu", "ur", "urd"),
    "uz": ("Uzbek", "uz", "uzb"),
    "vi": ("Vietnamese", "vi", "vie"),
}
SUB_FLAGS = "forced|sdh|cc|hi|default"


def lang_aliases(code):
    name, tag, extra = LANGUAGES[code]
    return {tag, code.lower(), name.split(" (")[0].lower(), *extra.split()}


def lang_sub_re(code):
    """Matches subtitle file names like Movie.en.srt, Movie.eng.forced.srt, Movie.English.srt."""
    names = "|".join(re.escape(a) for a in sorted(lang_aliases(code), key=len, reverse=True))
    return re.compile(rf"\.({names})(\.({SUB_FLAGS}))*\.(srt|ass|ssa|sub|vtt|smi)$", re.I)


def check_lang(code):
    if code not in LANGUAGES:
        raise SubError("Unknown language.")
    return code


DEFAULT_CONFIG = {
    "language": "en",
    "media_dirs": [],
    "api_key": "",
    "username": "",
    "password": "",
    "plex_url": "",
    "plex_token": "",
    "skip_machine_translated": True,
}
SECRETS = ("api_key", "password", "plex_token")

config_lock = threading.Lock()


class SubError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


# ---------------------------------------------------------------- config

def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        cfg.update(json.loads(CONFIG_PATH.read_text("utf-8")))
    except FileNotFoundError:
        pass
    return cfg


def save_config(cfg):
    CONFIG_PATH.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_suffix(".tmp")
    # Created private from the start, so the secrets are never readable by other users.
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(tmp, 0o600)
    tmp.replace(CONFIG_PATH)


def public_config(cfg):
    """Config as the browser sees it: secrets are never sent back."""
    out = {k: v for k, v in cfg.items() if k not in SECRETS}
    for k in SECRETS:
        out[k + "_set"] = bool(cfg.get(k))
    out["languages"] = sorted(({"code": c, "name": v[0]} for c, v in LANGUAGES.items()),
                              key=lambda lang: lang["name"])
    return out


def update_config(changes):
    with config_lock:
        cfg = load_config()
        old_plex_url = cfg["plex_url"]
        for key in DEFAULT_CONFIG:
            if key not in changes:
                continue
            value = changes[key]
            if key in SECRETS and not value:
                continue  # blank secret field means "keep the saved one"
            if key == "media_dirs":
                if isinstance(value, str):
                    value = value.splitlines()
                if not isinstance(value, list) or not all(isinstance(d, str) for d in value):
                    raise SubError("Media folders must be a list of folders.")
                value = [d.strip() for d in value if d.strip()]
            elif key == "skip_machine_translated":
                value = bool(value)
            elif not isinstance(value, str):
                raise SubError(f"Invalid value for {key}.")
            if key == "plex_url":
                value = check_plex_url(value)
            if key == "language":
                check_lang(value)
            cfg[key] = value.strip() if isinstance(value, str) else value
        # The Plex token only ever goes to the address it was entered for. Changing the
        # address without giving the token again forgets it, so it can't be redirected.
        if cfg["plex_url"] != old_plex_url and not changes.get("plex_token"):
            cfg["plex_token"] = ""
        save_config(cfg)
    client.reset()
    return cfg


def check_plex_url(url):
    url = url.strip().rstrip("/")
    if not url:
        return ""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise SubError("The Plex address must look like http://192.168.1.10:32400")
    return url


def as_int(value):
    """Numbers from OpenSubtitles, forced to be numbers before they reach the page."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------- OpenSubtitles

class OpenSubtitles:
    def __init__(self):
        self.lock = threading.Lock()
        self.reset()

    def reset(self):
        self.token = None
        self.base = API_ROOT
        self.last_call = 0.0

    def _request(self, method, path, params=None, body=None, auth=False, base=None):
        cfg = load_config()
        if not cfg["api_key"]:
            raise SubError("Add your OpenSubtitles API key in Settings first.")
        url = (base or self.base) + path
        if params:
            # OpenSubtitles asks for sorted, lower-case parameters (avoids redirects).
            items = sorted((k.lower(), str(v).lower()) for k, v in params.items()
                           if v not in (None, ""))
            url += "?" + urllib.parse.urlencode(items)
        headers = {"Api-Key": cfg["api_key"], "User-Agent": USER_AGENT,
                   "Accept": "application/json"}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        if auth:
            headers["Authorization"] = "Bearer " + self.token

        for attempt in range(3):
            with self.lock:  # stay well under the 5 requests/second limit
                wait = 0.3 - (time.time() - self.last_call)
                if wait > 0:
                    time.sleep(wait)
                self.last_call = time.time()
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                text = e.read().decode("utf-8", "replace")
                if e.code == 429 and attempt < 2:
                    time.sleep(2 * (attempt + 1))
                    continue
                try:
                    payload = json.loads(text)
                    msg = payload.get("message") or "; ".join(payload.get("errors", [])) or text
                except (ValueError, AttributeError):
                    msg = text[:200] or e.reason
                if e.code == 403 and "consume" in str(msg):
                    msg = "the API key was not accepted. Check it in Settings."
                raise SubError(f"OpenSubtitles: {msg}", e.code)
            except urllib.error.URLError as e:
                raise SubError(f"Could not reach OpenSubtitles ({e.reason}). Is the internet up?")

    def login(self):
        cfg = load_config()
        if not cfg["username"] or not cfg["password"]:
            raise SubError("Add your OpenSubtitles username and password in Settings "
                           "(needed to download).")
        res = self._request("POST", "/login", base=API_ROOT,
                            body={"username": cfg["username"], "password": cfg["password"]})
        self.token = res["token"]
        base_url = res.get("base_url")
        self.base = f"https://{base_url}/api/v1" if base_url else API_ROOT
        return res.get("user", {})

    def _authed(self, method, path, **kw):
        if not self.token:
            self.login()
        try:
            return self._request(method, path, auth=True, **kw)
        except SubError as e:
            if e.status != 401:
                raise
            self.login()
            return self._request(method, path, auth=True, **kw)

    def search(self, params):
        return self._request("GET", "/subtitles", params=params).get("data", [])

    def download(self, file_id):
        return self._authed("POST", "/download", body={"file_id": file_id, "sub_format": "srt"})

    def user_info(self):
        return self._authed("GET", "/infos/user").get("data", {})


client = OpenSubtitles()


# ------------------------------------------------------------ media files

def movie_hash(path):
    """OpenSubtitles hash: file size + 64-bit sums of the first and last 64 KB."""
    size = os.path.getsize(path)
    if size < 131072:
        return None
    h = size
    with open(path, "rb") as f:
        for offset in (0, size - 65536):
            f.seek(offset)
            for (x,) in struct.iter_unpack("<Q", f.read(65536)):
                h = (h + x) & 0xFFFFFFFFFFFFFFFF
    return f"{h:016x}"


EP_RE = re.compile(r"\b[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})|\b(\d{1,2})x(\d{2,3})\b")
YEAR_RE = re.compile(r"(?:^|[ ._(\[-])((?:19|20)\d{2})(?=$|[ ._)\]-])")
JUNK_RE = re.compile(
    r"\b(2160p|1080p|1080i|720p|576p|480p|4k|uhd|bluray|blu-ray|brrip|bdrip|web-?dl|webrip|web|"
    r"hdtv|dvdrip|dvd|xvid|divx|x264|x265|h\.?264|h\.?265|hevc|avc|aac|ac3|dts|ddp?5\.1|hdr|"
    r"remux|proper|repack|extended|unrated|remastered|multi|nordic|swesub)\b.*", re.I)
SEASON_DIR_RE = re.compile(
    r"^(season|series|staffel|saison|temporada|stagione|seizoen|säsong|sesong|sæson|kausi|sezon|s)"
    r"\s*\d+$|^specials$", re.I)


def tidy(text):
    text = re.sub(r"[._]+", " ", text)
    text = JUNK_RE.sub("", text)
    text = re.sub(r"[\[({][^\])}]*[\])}]", "", text)
    return re.sub(r"\s+", " ", text).strip(" -([{")


def words(text):
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def parse_name(path):
    p = Path(path)
    stem = p.stem
    ep = EP_RE.search(stem)
    if ep:
        title = tidy(stem[:ep.start()])
        if not title:
            for parent in list(p.parents)[:3]:
                name = tidy(parent.name)
                if name and not SEASON_DIR_RE.match(name):
                    title = name
                    break
        title = re.sub(r"\s(19|20)\d{2}$", "", title)
        return {"kind": "episode", "title": title, "year": None,
                "season": int(ep.group(1) or ep.group(3)),
                "episode": int(ep.group(2) or ep.group(4))}

    years = [m for m in YEAR_RE.finditer(stem) if m.start() > 0]
    if years:
        m = years[-1]
        title, year = tidy(stem[:m.start()]), int(m.group(1))
    else:
        title, year = tidy(stem), None
    if not title:
        title = tidy(p.parent.name)
    return {"kind": "movie", "title": title, "year": year, "season": None, "episode": None}


def media_roots():
    return [os.path.realpath(os.path.expanduser(d)) for d in load_config()["media_dirs"]]


def check_path(path):
    """Only allow video files inside the configured media folders."""
    real = os.path.realpath(path)
    if os.path.splitext(real)[1].lower() not in VIDEO_EXT:
        raise SubError("That is not a video file.")
    for root in media_roots():
        if real.startswith(root.rstrip(os.sep) + os.sep):
            return real
    raise SubError("That file is not inside your media folders.")


def sub_path(video, lang, ext=".srt"):
    return f"{os.path.splitext(video)[0]}.{LANGUAGES[lang][1]}{ext}"


library = {"items": [], "time": 0.0}  # last scan, reused when matching imports


def get_library(max_age=300):
    if time.time() - library["time"] > max_age:
        scan()
    return library["items"]


def scan():
    items, problems = [], []
    has_lang = lang_sub_re(load_config()["language"])
    for root in media_roots():
        if not os.path.isdir(root):
            problems.append(f"Folder not found or not mounted: {root}")
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames
                                 if not d.startswith(".") and d.lower() not in SKIP_DIRS)
            lower = [f.lower() for f in filenames]
            for name in filenames:
                stem, ext = os.path.splitext(name)
                if ext.lower() not in VIDEO_EXT or re.search(r"\bsample\b", name, re.I):
                    continue
                prefix = stem.lower() + "."
                has_sub = any(f.startswith(prefix) and has_lang.search(f) for f in lower)
                full = os.path.join(dirpath, name)
                items.append({"path": full, "rel": os.path.relpath(full, root),
                              "has_sub": has_sub, **parse_name(full)})
    items.sort(key=lambda i: i["rel"].lower())
    library.update(items=items, time=time.time())
    return {"items": items, "problems": problems}


# ------------------------------------------------------ search & download

def find_subs(path):
    info = parse_name(path)
    lang = load_config()["language"]
    try:
        mhash = movie_hash(path)
    except OSError:
        mhash = None

    searches = []
    if mhash:
        searches.append({"languages": lang, "moviehash": mhash})
    query = {"languages": lang, "query": info["title"]}
    if info["kind"] == "episode":
        query.update(type="episode", season_number=info["season"], episode_number=info["episode"])
    elif info["year"]:
        query.update(type="movie", year=info["year"])
    if info["title"]:
        searches.append(query)

    video_words = words(Path(path).stem)
    found = {}
    for params in searches:
        for item in client.search(params):
            a = item.get("attributes", {})
            fd = a.get("feature_details") or {}
            for f in a.get("files", []):
                fid = f["file_id"]
                if fid in found:
                    found[fid]["hash_match"] |= bool(a.get("moviehash_match"))
                    continue
                release = str(a.get("release") or f.get("file_name") or "")
                rel_words = words(release)
                similarity = (len(rel_words & video_words) / len(rel_words | video_words)
                              if rel_words else 0.0)
                found[fid] = {
                    "file_id": fid,
                    "release": release,
                    "file_name": str(f.get("file_name") or ""),
                    "downloads": as_int(a.get("download_count")) or 0,
                    "hash_match": bool(a.get("moviehash_match")),
                    "machine": bool(a.get("machine_translated") or a.get("ai_translated")),
                    "hearing_impaired": bool(a.get("hearing_impaired")),
                    "trusted": bool(a.get("from_trusted")),
                    "similarity": round(similarity, 3),
                    "feature": str(fd.get("title") or fd.get("movie_name") or ""),
                    "year": as_int(fd.get("year")),
                    "season": as_int(fd.get("season_number")),
                    "episode": as_int(fd.get("episode_number")),
                }

    results = list(found.values())
    for r in results:
        r["plausible"] = is_plausible(r, info)
        r["score"] = score(r, info)
    results.sort(key=lambda r: r["score"], reverse=True)
    return {"info": info, "hash": mhash, "language": lang, "results": results}


def is_plausible(r, info):
    if r["hash_match"]:
        return True
    if info["kind"] == "episode":
        return r["season"] == info["season"] and r["episode"] == info["episode"]
    if info["year"] and r["year"]:
        return abs(r["year"] - info["year"]) <= 1
    return r["similarity"] >= 0.3


def score(r, info):
    s = 0.0
    if r["hash_match"]:
        s += 1000
    if not r["plausible"]:
        s -= 800
    s += 300 * r["similarity"]
    s += min(r["downloads"], 40000) ** 0.5  # up to +200
    if r["trusted"]:
        s += 25
    if r["machine"]:
        s -= 400
    if r["hearing_impaired"]:
        s -= 10
    return round(s, 1)


def decode_subtitle(data):
    if data[:2] == b"\x1f\x8b":
        # Unpack gzip with a size cap, so a tiny file can't expand to gigabytes in memory.
        unpacker = zlib.decompressobj(16 + zlib.MAX_WBITS)
        try:
            data = unpacker.decompress(data, MAX_SUB_BYTES + 1)
        except zlib.error:
            raise SubError("Damaged compressed subtitle.")
        if len(data) > MAX_SUB_BYTES:
            raise SubError("File is too big to be a subtitle.")
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1252", "replace")  # the usual encoding of older Western subtitles


def download_to(video, file_id):
    lang = load_config()["language"]
    res = client.download(int(file_id))
    link = res.get("link")
    if not link:
        raise SubError(res.get("message") or "OpenSubtitles did not return a download link.")
    if not str(link).startswith("https://"):
        raise SubError("OpenSubtitles returned an unexpected download link.")
    req = urllib.request.Request(link, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = resp.read(MAX_SUB_BYTES + 1)
        if len(data) > MAX_SUB_BYTES:
            raise SubError("The downloaded file is too big to be a subtitle.")
        text = decode_subtitle(data)
    except urllib.error.URLError as e:
        raise SubError(f"Downloading the subtitle failed ({e}).")
    out = sub_path(video, lang)
    write_subtitle(out, text)
    return {"saved": out, "saved_name": os.path.basename(out),
            "remaining": res.get("remaining"), "reset_time": res.get("reset_time")}


def write_subtitle(out, text):
    # Never follow a symlink: someone who can write in the media folder could otherwise
    # point "Movie.en.srt" at another file and have it overwritten.
    if os.path.islink(out):
        raise SubError("A link with the subtitle's name is in the way. Nothing was written.")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0)
    try:
        with os.fdopen(os.open(out, flags, 0o644), "w", encoding="utf-8", newline="") as f:
            f.write(text)
    except OSError as e:
        raise SubError(f"Could not save next to the video ({e.strerror}). "
                       "Is the media folder read-only for this user?")


def auto_fetch(video, overwrite=False):
    cfg = load_config()
    name = LANGUAGES[cfg["language"]][0]
    if os.path.exists(sub_path(video, cfg["language"])) and not overwrite:
        return {"status": "skipped", "message": f"Already has a {name} subtitle."}
    found = find_subs(video)
    candidates = [r for r in found["results"]
                  if r["plausible"] and not (cfg["skip_machine_translated"] and r["machine"])]
    if not candidates:
        msg = (f"No {name} subtitle found." if not found["results"]
               else "No confident match. Use Choose to pick one yourself.")
        return {"status": "none", "message": msg, "count": len(found["results"])}
    best = candidates[0]
    saved = download_to(video, best["file_id"])
    return {"status": "saved", "release": best["release"], "hash_match": best["hash_match"],
            **saved}


# ------------------------------------------------ import from the browser

ALL_ALIASES = set().union(*(lang_aliases(c) for c in LANGUAGES), {"hi"})
TAG_RE = re.compile(r"\.(" + "|".join(re.escape(a) for a in sorted(ALL_ALIASES, key=len, reverse=True))
                    + rf"|{SUB_FLAGS})$", re.I)
# Words that say what language a file is rather than what it's called.
IGNORE_WORDS = ({"sub", "subs", "subtitle", "subtitles", "the", "a"}
                | {v[0].split(" (")[0].lower() for v in LANGUAGES.values()}
                | {a for v in LANGUAGES.values() for a in v[2].split() if len(a) > 3})
staged = {}  # upload id -> {"text", "ext", "time"}; kept until saved or two hours old
staged_lock = threading.Lock()


def unpack(rel, data):
    """Return (name, bytes) for each subtitle in an upload. Zip files are opened."""
    if rel.lower().endswith(".zip"):
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise SubError("Not a valid zip file.")
        subs = [zi for zi in zf.infolist()
                if not zi.is_dir() and zi.file_size <= MAX_SUB_BYTES
                and os.path.splitext(zi.filename)[1].lower() in SUB_EXT]
        if len(subs) > MAX_ZIP_FILES:
            raise SubError(f"Too many files in this zip (the limit is {MAX_ZIP_FILES}).")
        if sum(zi.file_size for zi in subs) > MAX_BODY_BYTES:
            raise SubError("This zip unpacks to too much data.")
        # zipfile never unpacks more than each entry's declared size, so the checks hold.
        found = [(f"{rel[:-4]}/{zi.filename}", zf.read(zi)) for zi in subs]
        if not found:
            raise SubError("No subtitle files inside this zip.")
        return found
    if os.path.splitext(rel)[1].lower() not in SUB_EXT:
        raise SubError("Not a subtitle file.")
    if len(data) > MAX_SUB_BYTES:
        raise SubError("File is too big to be a subtitle.")
    return [(rel, data)]


def match_subtitle(rel, items):
    """Rank library videos by how well they fit a subtitle's file name and folders."""
    p = Path(rel)
    stem = p.stem
    while TAG_RE.search(stem):
        stem = TAG_RE.sub("", stem)
    info = parse_name(str(p.with_name(stem + ".srt")))
    sub_words = words(info["title"]) - IGNORE_WORDS
    same_name = {stem.lower(), p.stem.lower()}

    scored = []
    for it in items:
        vid_words = words(it["title"]) - IGNORE_WORDS
        sim = (len(vid_words & sub_words) / len(vid_words | sub_words)
               if vid_words and sub_words else 0.0)
        if Path(it["path"]).stem.lower() in same_name:
            s = 100 + 10 * sim  # the title breaks ties between bare names like S01E03
        elif info["kind"] == "episode":
            if (it["season"], it["episode"]) != (info["season"], info["episode"]):
                continue
            s = 40 + 50 * sim
        else:
            if it["kind"] == "episode" or sim < 0.3:
                continue
            if info["year"] and it["year"]:
                if abs(info["year"] - it["year"]) > 1:
                    continue
                s = 80 * sim + (10 if info["year"] == it["year"] else 0)
            else:
                s = 75 * sim
        scored.append((round(s, 1), it))
    scored.sort(key=lambda x: x[0], reverse=True)

    out = []
    for i, (s, it) in enumerate(scored[:5]):
        conf = "exact" if s >= 100 else "likely" if s >= 65 else "unsure"
        if i == 0 and conf != "unsure" and len(scored) > 1 and scored[1][0] >= s - 5:
            conf = "unsure"  # two videos fit about equally well
        out.append({**it, "score": s, "confidence": conf})
    return out


def stage(text, ext, now):
    """Hold an imported subtitle until it's saved. Oldest uploads make room for new ones."""
    sid = secrets.token_hex(16)
    with staged_lock:
        for key in [k for k, v in staged.items() if v["time"] < now - 3600]:
            del staged[key]
        staged[sid] = {"text": text, "ext": ext, "time": now}
        total = sum(len(v["text"]) for v in staged.values())
        for key in sorted(staged, key=lambda k: staged[k]["time"]):
            if total <= MAX_STAGED_BYTES or key == sid:
                break
            total -= len(staged.pop(key)["text"])
    return sid


def stage_files(files, lang):
    check_lang(lang)
    if not isinstance(files, list):
        raise SubError("Expected a list of files.")
    now = time.time()
    items = get_library()

    entries = []
    for f in files:
        rel = str(f.get("rel") or "subtitle").replace("\\", "/") if isinstance(f, dict) else "?"
        try:
            subs = unpack(rel, base64.b64decode(f.get("data", ""), validate=True))
            decoded = [(name, decode_subtitle(raw)) for name, raw in subs]
        except (SubError, ValueError, AttributeError) as e:
            msg = str(e) if isinstance(e, SubError) else "Could not read this file."
            entries.append({"name": rel, "error": msg})
            continue
        for name, text in decoded:
            ext = os.path.splitext(name)[1].lower()
            sid = stage(text, ext, now)
            candidates = match_subtitle(name, items)
            for c in candidates:
                c["exists"] = os.path.exists(sub_path(c["path"], lang, ext))
            entries.append({"id": sid, "name": name, "candidates": candidates})
    return {"entries": entries}


def save_import(sid, video, lang, overwrite):
    check_lang(lang)
    with staged_lock:
        entry = staged.get(sid)
    if not entry:
        raise SubError("This upload has expired. Add the files again.")
    out = sub_path(video, lang, entry["ext"])
    if os.path.exists(out) and not overwrite:
        raise SubError("That video already has a subtitle with this name. Nothing was replaced.")
    write_subtitle(out, entry["text"])
    with staged_lock:
        staged.pop(sid, None)
    return {"saved": out, "saved_name": os.path.basename(out)}


# ------------------------------------------------------------------- Plex

def plex_refresh():
    cfg = load_config()
    if not cfg["plex_url"] or not cfg["plex_token"]:
        raise SubError("Add your Plex address and token in Settings to use this.")
    headers = {"X-Plex-Token": cfg["plex_token"], "Accept": "application/json"}

    def get(path):
        req = urllib.request.Request(cfg["plex_url"] + path, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read()
                return json.loads(body) if body.strip() else {}
        except urllib.error.HTTPError as e:
            raise SubError(f"Plex answered {e.code}. Check the token." if e.code == 401
                           else f"Plex error {e.code}.")
        except urllib.error.URLError as e:
            raise SubError(f"Could not reach Plex at {cfg['plex_url']} ({e.reason}).")

    sections = get("/library/sections").get("MediaContainer", {}).get("Directory", [])
    for s in sections:
        get(f"/library/sections/{s['key']}/refresh")
    return {"refreshed": [s.get("title") for s in sections]}


# --------------------------------------------------------------- web server

def host_allowed(host_header):
    """Accept IP addresses and this machine's own names. A web page that points its own
    domain at this machine (DNS rebinding) sends its domain here, and is refused."""
    host = (host_header or "").strip().lower()
    if host.startswith("["):  # [IPv6]:port
        host = host[1:].split("]")[0]
    elif host.count(":") == 1:
        host = host.split(":")[0]
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return host in ALLOWED_HOSTS


def client_allowed(ip):
    """Local network, VPN and this machine only, unless public access is switched on."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if getattr(addr, "ipv4_mapped", None):
        addr = addr.ipv4_mapped
    return ALLOW_PUBLIC or not addr.is_global


def password_ok(auth_header):
    if not PASSWORD:
        return True
    if not (auth_header or "").startswith("Basic "):
        return False
    try:
        _, _, given = base64.b64decode(auth_header[6:]).decode("utf-8").partition(":")
    except (ValueError, UnicodeDecodeError):
        return False
    return hmac.compare_digest(given.encode(), PASSWORD.encode())


class Handler(BaseHTTPRequestHandler):
    server_version = f"SubtitlesForPlex/{VERSION}"

    def log_message(self, fmt, *args):
        pass

    def end_headers(self):
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "frame-ancestors 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()

    def allowed(self):
        """Checks every request must pass. Sends the refusal itself and returns False."""
        if not client_allowed(self.client_address[0]):
            self.send_json({"error": "Only devices on the local network may use this. "
                                     "See the README to allow more."}, 403)
        elif not host_allowed(self.headers.get("Host")):
            self.send_json({"error": "Unknown host name. Add it to "
                                     "SUBTITLES_FOR_PLEX_ALLOWED_HOSTS (see the README)."}, 403)
        elif not password_ok(self.headers.get("Authorization")):
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Subtitles for Plex", charset="UTF-8"')
            self.send_header("Content-Length", "0")
            self.end_headers()
        else:
            return True
        return False

    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def handle_api(self, fn):
        try:
            self.send_json(fn())
        except SubError as e:
            self.send_json({"error": str(e)}, 400)
        except Exception as e:  # keep the UI alive and show what went wrong
            self.send_json({"error": f"{type(e).__name__}: {e}"}, 500)

    def do_GET(self):
        if not self.allowed():
            return
        route = urllib.parse.urlparse(self.path).path
        if route in ("/", "/index.html"):
            body = (HERE / "index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif route == "/api/config":
            self.handle_api(lambda: public_config(load_config()))
        elif route == "/api/scan":
            self.handle_api(scan)
        elif route == "/api/account":
            self.handle_api(client.user_info)
        else:
            self.send_error(404)

    def do_POST(self):
        if not self.allowed():
            return
        # Requiring JSON forces a CORS preflight, so other websites can't drive this app.
        if not self.headers.get("Content-Type", "").startswith("application/json"):
            self.send_json({"error": "Expected JSON."}, 415)
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = -1
        if length < 0:
            self.send_json({"error": "Bad request."}, 400)
            return
        if length > MAX_BODY_BYTES:
            self.send_json({"error": "Upload too big. Try fewer files at once."}, 413)
            return
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            body = None
        if not isinstance(body, dict):
            self.send_json({"error": "Bad JSON."}, 400)
            return
        route = urllib.parse.urlparse(self.path).path
        routes = {
            "/api/config": lambda: public_config(update_config(body)),
            "/api/search": lambda: find_subs(check_path(body.get("path", ""))),
            "/api/download": lambda: download_to(check_path(body.get("path", "")),
                                                 body.get("file_id")),
            "/api/auto": lambda: auto_fetch(check_path(body.get("path", "")),
                                            bool(body.get("overwrite"))),
            "/api/plex-refresh": plex_refresh,
            "/api/import/stage": lambda: stage_files(body.get("files", []), body.get("lang", "")),
            "/api/import/save": lambda: save_import(body.get("id", ""),
                                                    check_path(body.get("path", "")),
                                                    body.get("lang", ""),
                                                    bool(body.get("overwrite"))),
        }
        if route in routes:
            self.handle_api(routes[route])
        else:
            self.send_error(404)


def main():
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"{APP} running. Open http://localhost:{PORT} (or this machine's IP) in a browser.", flush=True)
    print(f"Settings are stored in {CONFIG_PATH}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBye!")


if __name__ == "__main__":
    main()
